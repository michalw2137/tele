//
// Created by wrzos on 13.03.2022.
//

#ifndef BLEDY_KODY_KONTROLER_H
#define BLEDY_KODY_KONTROLER_H


class Kontroler {

public:
    void koduj();

    void dekoduj();
};


#endif //BLEDY_KODY_KONTROLER_H
